# Design Critic Goldfish — BRAINSTORM findings

Persona identity: **Design Critic Goldfish**, operating as the delegated **Design Critic-Brainstormer**. Mode: **BRAINSTORM**. This evaluates architecture, resource limits, integration burden, and token economics for trusted single-user local use. It is not a formal design-completeness audit.

## Reading and standards receipt

Read the installed persona in full: `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/design_critic.md`, including its universal mandates, BRAINSTORM instructions, REVIEW-only instructions, audit vectors, and output formats. The delegated exception authorizes only this findings file; no implementation or input edits were made.

Required documents, each read in full with numbered lines:

| Reference | Absolute path | Full-read receipt |
| --- | --- | --- |
| N | `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` | All 294 lines, including accepted demonstration, recovery concerns, and final anchored hypothesis. |
| B | `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md` | All 83 lines, including decision-page/Live distinctions and research limits. |
| H | `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md` | All 85 lines, including candidate/OpenRouter table, hook boundaries, and restart requirements. |

Standards receipt: **None required in BRAINSTORM by this persona or supplied as a target standard.** No REVIEW checklist was imposed. No other reviewers, hidden chats, memory, credentials, or prior-project files were read. Linked external documentation was not independently revalidated; the evidence classification in the supplied research is preserved.

## Overall assessment

The hypothesis is plausible and worth retaining. Reusing host execution and model integration is a real reduction in owned machinery. The browser-input precedent is substantive; it does not establish repeated play, effective checkpoints, or inexpensive waiting for this package. No demonstrated impossibility warrants a concept blocker. The most consequential unknown is whether the shared-file boundary stays small when two writers, two conversations, restoration, and freely chosen editing tools interact.

All recommendations below are **proposals**, not accepted decisions. “Mitigation requirement” identifies an outcome I propose carrying into the concepts brief; it does not select a protocol or authorize implementation.

## Prioritized objections

### 1. Shared-log flexibility has a real concurrency cost

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — file coordination and recovery effort.

**Affected scope:** N, “Shared public conversation logs,” lines 158–173; N, “Prose display,” lines 142–156; B, “Implications to discuss,” lines 57–61.

**Risk:** A writer can read the story log, compose a replacement, and save after the browser has appended another player entry. That save erases the new input. Arbitrary editing tools make an advisory lock unreliable unless the writer actually follows the agreement. Separately, a late Director correction can arrive while prose is being prepared and cannot be assumed to govern that already-produced response. These are plausible failures with one human and one agent; high QPS is unnecessary. Fixing them retrospectively costs model rereads, user reconstruction, and trust.

**Strongest counterargument:** Single-user story exchanges are slow and normally sequential. A conventional readable log plus agent guidance may suffice without database transactions or universal tool interception.

**Proposed mitigation requirement:** Establish a small agreement that preserves accepted human input under the editing methods actually used and makes late Director messages visibly pending until handled. State the supported concurrency behavior; do not imply safe concurrent whole-file replacement merely because all editing tools are permitted. Keep writer choice of tools and writer discretion over Director blocking.

**Genuinely smaller alternative:** Keep both roles in the same story log, append new exchanges, and use a short, voluntary exclusive-edit interval only for authorized historical rewrites. If narrower behavior proves insufficient, add a revision check or brief shared lock. Neither requires routing every tool through a controller. Restricting ordinary player submissions to one outstanding story exchange is another proposal for discussion, not an inferred user decision.

### 2. Local polling can still create expensive host activity

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — idle token use, quota consumption, and latency.

**Affected scope:** N, “Assumptions that need evidence,” lines 120–124; B, decision-page path, lines 22–26 and Live path, lines 38–42; H, lines 45–55 and 79–80.

**Risk:** A quiet helper can poll locally without LLM use, yet the host may repeatedly return a timeout/yield to the agent and require another reasoning/tool cycle. Over an idle duration T with model-serviced renewal interval Δ, the possible renewal count grows approximately as T/Δ. The relevant measurement is those host/model renewals and their token use, not the helper’s filesystem-check count. The design can therefore be inexpensive per story exchange but wasteful while the human reads or leaves the browser open. Browser-side animation does not reduce composition latency.

**Strongest counterargument:** Hosts already support long-running tools or event delivery. An appropriate existing path may make idle cost negligible, and ordinary reading pauses may be short.

**Proposed mitigation requirement:** Describe waiting as bounded by observed host behavior, expose a recoverable ended/disconnected state, and compare idle overhead alongside normal reply latency in the accepted short-scene experience. Avoid a promise of indefinite free waiting. Do not import previous numerical budgets.

**Genuinely smaller alternative:** One quiet blocking wait with the chosen host’s existing result-delivery mechanism, plus a clear manual resume after exceptional expiration. Automatic relaunchers, watchdog agents, and a custom session daemon are unjustified unless the actual ordinary experience requires them.

### 3. Undo also restores progress state, not just fiction

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — recovery coherence and repeated model work.

**Affected scope:** N, “Git checkpoints and Undo,” lines 193–219; N, shared-log questions, lines 168–173; H, restart, lines 69–75.

**Risk:** Restoring a log together with a handled-input marker can resurrect an old human entry as “new.” Restoring the log without the corresponding progress state can instead strand an unhandled entry. A Director rejection may be newer than the checkpoint. A stale browser tab or helper may still hold content from before restoration. The document correctly recognizes lost corrections and concurrent writes, but the same shared-file mechanism also needs a coherent answer for what the writer waits for after Undo. Otherwise the required wait-for-direction can accidentally consume old story input and regenerate prose.

**Strongest counterargument:** Undo is a writer-mediated Director action, so it can inspect files and explain a coarse recovery. A full transaction journal or interaction-perfect rollback is unnecessary.

**Proposed mitigation requirement:** Preserve the relevant Director correction, establish which human inputs remain pending after restoration, and enter the required Director wait explicitly. Require a quiet boundary for writers of restored material. This concerns the integrity of a coarse restoration, not greater historical precision than the user accepted.

**Genuinely smaller alternative:** Use the accepted writer-led restoration, retain a small restoration explanation and pending Director instruction, then reopen/reload the helper if its in-memory state is uncertain. A fresh compatible session is a possible fallback if the live agent repeatedly reuses rejected material. No branching-history UI, per-response snapshot scheme, or browser Stop feature follows.

### 4. Hook enforcement is still conceptually underspecified at the chosen loop boundary

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — integration burden and false checkpoint confidence.

**Affected scope:** N, lines 69–71, 197–211; H, “Hook boundaries,” lines 57–63; H, Codex, lines 47–49.

**Risk:** A Stop hook may never run during a multi-exchange wait loop. Conversely, a dirty-tree check before every wait might effectively force one commit per reply, silently replacing writer-chosen granularity. A writer-created or restored hook definition can also differ from the trusted definition the host currently runs. “Hooks ensure changed work is checkpointed” therefore needs an explicit, limited meaning before it becomes a product promise.

**Strongest counterargument:** The notes already identify this distinction. Ordinary guidance and a supported completion hook may be sufficient for the initial scene; this does not demand an elaborate enforcement layer.

**Proposed mitigation requirement:** Carry a concrete checkpoint obligation and a named enforcement boundary into later design, while preserving writer-chosen commit timing. Treat a changed hook as needing the host’s actual activation path; never infer activation from its file existing. A check should report precisely what it proves.

**Genuinely smaller alternative:** Keep a small stable mechanical checkpoint hook and let the writer adapt its other methods freely. Use an explicit pause/close checkpoint as a possible boundary, with any before-wait check limited to a narrowly stated condition rather than an automatic commit-per-response rule. The precise condition remains a design choice.

### 5. Fresh-context portability transfers cost into knowledge maintenance

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — context budget, retrieval effort, and continuity repair.

**Affected scope:** N, persistence, lines 65–72; N, restart, lines 223–229; H, lines 69–75; N, demonstration, lines 102–106.

**Risk:** Freeform self-managed notes can meet the requirement, but nothing demonstrated yet shows a new writer can locate the necessary facts economically. Reading the entire growing prose log on each restart or response makes input work grow with accumulated history; repeatedly reconstructing state from cards and transcript undermines the intended durable knowledge representation. The accepted scene can appear successful entirely because one live context remembers everything.

**Strongest counterargument:** A short scene needs little storage, and agents can maintain useful indexes without a fixed world schema. Formal retrieval infrastructure would cost more than it saves at this scale.

**Proposed mitigation requirement:** Keep discoverability and actual fresh-context continuation explicit outcomes, with a small restart observation early enough to inform portability claims. Observe what the fresh session needed to read and what it missed, rather than declaring success because notes and commits exist. This may be adjacent to the accepted short scene; it need not expand that scene into a mystery arc.

**Genuinely smaller alternative:** One maintained entry-point note pointing to the writer’s own records, a concise current-state summary, and selectively read prior prose. Let the writer reorganize those records. No database, embeddings, fixed world schema, or semantic-completeness hook is warranted.

### 6. Multi-host support multiplies setup combinations before model choice does

**Severity:** Major. **Dimension:** Cost, Quota & Token Economics — maintenance and compatibility effort.

**Affected scope:** N, anchored hypothesis, lines 288–290; H, support/model table, lines 15–33; H, lines 65–67 and 77–85.

**Risk:** “Claude Code,” “Codex,” a particular desktop/CLI surface, trusted hooks, and an OpenRouter model pairing are different support variables. Adding four more hosts can make the comparison itself larger than the minimal package. A launcher route on a required host may reduce host count but create adapter-specific limitations; a native OpenRouter host may be simpler despite being a third host. Documentation does not determine this trade-off. Supporting selectable models also cannot economically mean proving every catalog model equally reliable.

**Strongest counterargument:** Most files and helper code can be shared. Existing integrations may leave only short host-specific instructions, and the requirement intentionally avoids owning model calls.

**Proposed mitigation requirement:** Preserve both required hosts, distinguish investigated candidates from supported configurations, and describe evidence at the host/surface/integration level actually observed. Compare the total setup and lifecycle burden of one existing OpenRouter route before extending the support promise. Model choice remains open, with honest capability limits.

**Genuinely smaller alternative:** One shared browser/file helper, thin host-specific instructions for Claude Code and Codex, and the smallest existing-host OpenRouter route demonstrated to preserve the needed tools and lifecycle. Keep other candidates as documented alternatives until they solve an observed gap. Do not add a provider controller or certify the whole model catalog.

## Proportionate economics and resource limits

Peak QPS, database query load, and storage throughput are not credible primary bottlenecks for the accepted single-user short scene. There is no database requirement to optimize. The limiting costs are model context/reasoning, tool cycles, setup maintenance, and recovery effort. Plain prose and notes do not justify storage quotas at this stage. Repeatedly rewriting binary card images or committing transient generated/build files could add avoidable Git bulk later; the current PNG-only scene gives no evidence that storage engineering is needed. Preserve originals, avoid unnecessary duplication, and observe actual growth before choosing limits.

Browser-side reveal and deferred image generation are good scope reductions. Optional subagents should remain optional: they add token cost and make a quiet restoration boundary harder. Trusted local use calls for an intentionally scoped local file bridge and public/private material agreement, not an SRE platform, containers, production availability targets, or a new permissions service.

## Unresolved assumptions

- Which actual host surfaces and existing OpenRouter integration preserve the required tools, wait lifecycle, and hook behavior?
- What exceptional interruption experience is acceptable when the helper remains alive but the agent no longer services results?
- What behavior prevents lost or replayed human entries while allowing arbitrary editing tools and discretionary Director blocking?
- What exactly counts as changed work that must be checkpointed, and at which boundary is that condition checked?
- How are current Director corrections, pending inputs, restored story records, and helper/browser state reconciled during Undo?
- Can a fresh compatible session discover enough knowledge without expensive transcript reconstruction, and can a live session stop treating rejected material as authority?

## Concept decisions versus later design details

Proposed concept-level work: retain the accepted scene and lightweight existing-host boundary; settle the supported concurrency semantics, bounded interruption experience, concrete checkpoint promise, recovery/pending-input outcome, and honest scope of host/model support. Preserve fresh-context continuation as a required outcome rather than a saved-chat shortcut. These choices determine whether the package is actually small.

Suitable for later formal design: filenames, role markers, message identifiers, append/replace mechanics, locking or revision-check implementation, exact wait renewal strategy, hook event and condition, Git restore commands and excluded files, browser notification transport, portrait association, and reveal/change indicators. Those details should realize the chosen outcomes without imposing a private-world schema or mandatory per-interaction rollback.

No finding converts the outstanding Impeccable pass into an implementation approval. No blocker is asserted from missing production infrastructure or from the fact that live compatibility evidence has not yet been collected during this brainstorm.
