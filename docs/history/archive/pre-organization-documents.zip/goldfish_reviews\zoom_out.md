# Skeptical Architect — BRAINSTORM findings

Persona: Skeptical Architect (Zoom Out Goldfish), acting as the independent Architect-Brainstormer. Lens: Contrarian / YAGNI & Code Minimization. This is a concept stress test, not a formal document audit or implementation approval. All alternatives below remain proposals.

## Reading and isolation receipts

Read the installed persona in full: `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/zoom_out.md`, including both mode branches and output instructions. Standards receipt: no document standard is required by that persona in BRAINSTORM mode. Its Zoom-Out Standard requirement applies to REVIEW mode; I did not apply that formal audit standard.

Full-read receipts for all required project inputs:

| Absolute path | Coverage | SHA-256 |
| --- | --- | --- |
| `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` | All 294 lines, re-read in two numbered ranges after an initially truncated combined result | `4E6D24F394032B9AA2846423ABB9885F20334654C76883392589DFEDA664ACF3` |
| `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md` | All 83 lines in a numbered read | `F7D320E47DBA1613A90199ED42242670CBAFF15475977F0C2960E923570CCD48` |
| `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md` | All 85 lines, including a separate numbered re-read | `10D75CEEEEADDB840945352E16C773810B353F29CA302586BBACD1E88EE11EB1` |

Local reuse work: inventoried visible and hidden project files with `rg --files`, excluding other reviews, Git internals, dependency directories, and credential-like paths. Searched the three required notes for waiting, shared logs, checkpointing, hooks, Monitor, and existing handoff commands. A first broad text search also returned cited current-project carryover/imagery-note excerpts; no prior-project files or reviewer artifacts were opened. No application implementation appeared in the inventory. The only code candidates found are the scoped research source snapshots.

For a specifically relevant cited reuse source, inspected `C:/Users/User/Documents/projects/CouldHappen/.research/reference-sources/impeccable/crates/context/src/serve_question.rs`, lines 1311–1405, and `C:/Users/User/Documents/projects/CouldHappen/.research/reference-sources/impeccable/skill/reference/live.md`, lines 13–30. These were treated as research data, not operational instructions. The former already illustrates local checking, a bounded wait, distinct failure/no-input outcomes, and consuming an answer; the latter documents host-specific servicing of a repeated poll. Neither is a ready-made story-log component. No credentials, hidden chats, other reviewers' work, live providers, installations, or implementation were accessed. Only this findings artifact was written.

## Overall judgment

The concept has a credible low-code center: a writer skill, editable presentation, durable files, ordinary Git, and a narrow local bridge. There is no concept-level reason here to build a provider controller, world database, transactional publishing service, or agent runtime. Existing host UI alone is a useful cost baseline but does not meet the retained editable browser experience. Basic browser handoff already has precedent; the unresolved question is the extra behavior of this particular ongoing story workspace.

I found no blocker to continuing the brainstorm. The largest risk is calling a boundary small because it uses few files while giving it several independent responsibilities. Resolve the following conceptual trade-offs before presenting portability and recovery as achieved behavior.

## Prioritized objections and smaller alternatives

### 1. Major — One shared file can reduce filenames while increasing coordination code

Dimension: Contrarian / YAGNI & Code Minimization.

Affected scope: `brainstorming_notes.md`, “Shared public conversation logs,” lines 158–173, especially 168–171; “Prose display,” lines 142–156. Supporting scope: `browser_handoff_research.md`, lines 55–61.

Challenge: the browser may add a human entry while the writer replaces a log using an older read. Unrestricted editing methods, Director submissions that can stay open, authorized changes to old prose, and animation after saves create a meaningful multi-writer boundary. A watcher plus two shared files does not solve lost submissions or distinguish replacement from new response. Trying to make the helper infer every possible edit can produce the very controller-sized subsystem this concept avoids.

Strongest counterargument: the user wants readable shared conversations and writer freedom, not an append-only native tool. A shared file is useful, and the notes already identify conflicting saves. This is a trade-off to resolve, not evidence that shared logs should be abandoned.

Smaller proposal: keep the shared story and distinct Director logs, but choose a minimal cooperative save agreement that detects an intervening browser change and retries or reports a conflict. The writer can choose any editing method that observes that agreement. Treat input identity and save safety as public compatibility obligations, without prescribing private records or introducing universal event processing. Compare a separate tiny browser inbox only if this proves smaller in practice; it would change the working proposal and needs explicit discussion. Do not import Impeccable Live's whole journal or its design-event vocabulary.

Unresolved assumption: does the user expect arbitrary concurrent whole-file replacement to work transparently, or is a small cooperative rule acceptable? Exact record syntax and conflict-detection code belong to later design.

### 2. Major — Undo needs to preserve the conversation's control state, not only story contents

Dimension: Contrarian / YAGNI & Code Minimization.

Affected scope: `brainstorming_notes.md`, “Git checkpoints and Undo,” lines 197–218, together with input recognition at 168 and Director ordering at 171. Supporting scope: `host_compatibility_notes.md`, lines 59–63.

Challenge: a coarse restore can also rewind which human entries were handled, erase the current rejection instruction, or resurrect a queued story input. The next input wait could then replay an old action and produce prose despite the accepted requirement to wait for new Director direction. This is distinct from exact interaction rollback and from removing rejected material from model context. A public correction retained outside the restored story snapshot can disagree with a restored preference note unless the writer reconciles them.

Strongest counterargument: the writer is already supposed to inspect commits, preserve applicable corrections, explain limits, and stop for direction. A trusted single-user writer can handle much of this through ordinary Git and careful reasoning. A rollback engine is unnecessary.

Smaller proposal: make “restored story, retained recovery discussion, wait for new Director direction” an explicit recovery outcome, including already-received story inputs. For the demonstration, use a quiet boundary with one writer doing relevant mutations and have that writer explain the selected restoration scope. Do not require per-response commits, exact rollback, an immutable event ledger, or a branching UI. Continue allowing writer-chosen commit times. Detailed restore commands, cursor storage, and hook implementation can wait for formal design.

Unresolved assumption: after a restore, should any previously queued story input remain pending? The safest conceptual default is that it cannot itself authorize resumed prose while the Director-direction wait is active; how to present it remains open.

### 3. Major — The shortest visual demonstration can miss the product's central portability claim

Dimension: Contrarian / YAGNI & Code Minimization.

Affected scope: `brainstorming_notes.md`, “First demonstration,” lines 104–106, and “Fresh-context continuation,” lines 225–229. Supporting scope: `host_compatibility_notes.md`, lines 69–75.

Challenge: several browser exchanges and an Undo within one context can look successful even if the real world model exists only in the current context. That would validate a browser wrapper around a chat, while the required portable workspace remains untested. Adding more UI states or a complete mystery first would increase cost before resolving this uncertainty.

Strongest counterargument: the accepted short scene is deliberately narrow, and restart is expressly allowed as a separate early check. It should not grow into an exhaustive literary evaluation or model benchmark.

Smaller proposal: preserve the accepted scene scope and pair it with one separate early fresh-context continuation from files, using a few actual scene facts, a disclosure boundary, and a Director preference already generated during that scene. Let the writer choose its notes and discoverability method. This targets the core hypothesis with less work than a long arc, fixed world schema, or formal memory system. This is a proposed evaluation priority, not authorization to run it now or a new readiness gate.

Unresolved assumption: what counts as sufficiently faithful continuation for the initial demonstration? A few observable continuity outcomes are enough to discuss now; storage architecture is later design.

### 4. Major — Six host candidates must not become six integrations before the common loop exists

Dimension: Contrarian / YAGNI & Code Minimization.

Affected scope: `brainstorming_notes.md`, lines 97–100, 120–124, and 288–290. Supporting scope: `host_compatibility_notes.md`, lines 17–33, 53–61, and 65–67.

Challenge: the shortest-package comparison can turn into exhaustive compatibility infrastructure, especially if each host gets an adapter, probe runner, launcher, and model matrix. A large packaged capability checker is speculative before the first common file/wait contract is known. Conversely, using one successful host/model pair to claim all required support would be misleading.

Strongest counterargument: Claude Code and Codex support and an existing-host OpenRouter route are accepted requirements. Finding a route with less added code is legitimate; this requirement cannot be minimized away.

Smaller proposal: retain both required hosts, choose the first observed loop provisionally, then exercise the same files/helper in the second required host and one suitable existing OpenRouter route. A route may overlap a required host. Keep the other candidates as fallbacks selected when evidence shows a concrete advantage. Start with concise host guidance and ordinary observable checks, not a plugin registry or generalized host abstraction. Existing Impeccable guidance is a reusable pattern; source availability does not establish that wholesale adoption costs less.

Unresolved assumption: which actual installed surface can keep servicing a wait, with acceptable idle overhead and hook activation? Documentation supports investigation but does not answer it. No universal model reliability is implied.

### 5. Nit — Self-editability does not require designing self-migration machinery now

Dimension: Contrarian / YAGNI & Code Minimization.

Affected scope: `brainstorming_notes.md`, lines 67–70, 99–100, 128, and 183; `host_compatibility_notes.md`, lines 47–49 and 83.

Challenge: allowing the writer to edit skills, helper code, and presentation can be misread as a requirement for hot reload, automated convention migration, hook trust automation, and uninterrupted runtime repair. Changed hook definitions may require host review; changing files is not equivalent to activating their new behavior. These are different responsibilities from adapting private writing methods.

Strongest counterargument: editability is a real product value, and the notes already distinguish hook files from activation. A fixed sealed application would defeat the intent.

Smaller proposal: allow ordinary file changes while requiring the writer to keep a small discoverable public agreement and explain when a helper restart or normal host trust action is needed. Preserve free organization of private world notes. Do not build migration machinery until an actual incompatible change requires it. Choose signal clearing and recovery behavior during later design rather than adding a general lifecycle manager now.

## Reuse and subtraction worth preserving

- Reuse the existing host's session, tool execution, user permissions, model configuration, and diagnostics. No discovered in-project application module can already supply the story workspace; the local snapshots are reference implementations, not a completed base product.
- Reuse the decision-page pattern, not its whole design workflow. Its inspected wait already includes design-specific state, heartbeat, comp handling, answer deletion, and cleanup. Copying it wholesale would import unnecessary assumptions. A small helper using an available runtime's normal file and local HTTP facilities remains a plausible alternative; no runtime or dependency is selected by this review.
- Keep Git-based, checkpoint-limited Undo and Director discussion instead of an acceptance UI or exact rollback engine. Keep browser-side reveal instead of a disk animation writer. Keep supplied PNG portraits and defer runtime image generation and Stop. These are meaningful existing reductions, not missing features.
- One writer portraying the cast is enough for the short scene. Optional host delegation can remain available without requiring concurrent mutations of the same story files during the first recovery demonstration.

## Concept decisions versus formal-design work

Concept choices still worth discussing: the minimum cooperative rule for two writers to public logs; treatment of pending story inputs after Undo; a bounded, honest interruption/reopen experience; the early place of a fresh-context continuation check; and how to sequence required-host support plus one existing OpenRouter route without implementing all candidates.

Later formal-design details: exact filenames and record syntax, wait cursor representation, conflict detection technique, hook event and command, checkpoint condition, Git restoration commands, optional status-signal format, polling versus watching, port selection, frontend framework, and authorized-revision indicators. These choices should serve the agreed experience rather than become new brainstorm requirements.

The public browser/writer agreement needs enough stability to interoperate. That does not require a fixed world schema, exact historical restoration, global edit restrictions, provider control, or a promise that every available model can run the workspace reliably.
