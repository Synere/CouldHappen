# Codebase Details Goldfish — BRAINSTORM findings

## Identity, scope, and read receipts

Reviewer: **Codebase Details Goldfish** (`egm-codebase-details`), operating in **BRAINSTORM** mode. Lens: observability and operational debuggability of the proposed fiction workspace, scaled to trusted single-user local use. This is concept critique, not a code/document completeness audit. Recommendations below are **proposals, not accepted decisions**. No implementation capability is certified by this review.

Full-read receipts:

- **Read in full:** `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/codebase_details.md` — installed reviewer persona, including both mode branches; applied only BRAINSTORM.
- **Read in full:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` — lines 1–294, including accepted decisions, superseded proposals, accepted short-scene scope, recovery concerns, and anchored hypothesis. The initially truncated display was supplemented by a separate read covering lines 106–166.
- **Read in full:** `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md` — lines 1–83.
- **Read in full:** `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md` — lines 1–85.
- **Read in full:** `C:/Users/User/Documents/projects/CouldHappen/carryover_audit.md` — lines 1–89.

**Standards receipt:** None required by the installed persona's BRAINSTORM branch. Its Target Standard instruction belongs to REVIEW and does not apply here. No additional standard was assumed or read.

No credentials, hidden chats/memory, other reviewers' findings, or previous-project files were inspected. Linked external implementation/documentation sources were not independently reverified: the supplied investigation's distinctions between inspected source, reported experience, inference, and unknown behavior are retained. Only this findings file was written.

## Overall assessment

The accepted short-scene demonstration is a sensible starting point. The notes correctly avoid claiming that skill discovery, a running helper, a hook file, or a Git commit establishes a reliable story loop or complete durable knowledge. Director chat plus existing host diagnostics is a proportionate operational model; distributed tracing, production alerting, exact token accounting, and a custom activity dashboard are not justified by this concept.

The strongest objection is not absence of monitoring machinery. It is that several independently failing components could present the same user-visible symptom: an unanswered story entry. A small boundary agreement must let the human distinguish what is known from what is merely hoped, and recover without duplicating an action or losing the Director's correction. The documents explicitly acknowledge many of these uncertainties; the findings below prioritize which outcomes deserve concept-level commitment rather than treating acknowledged questions as implementation defects. No Blocker is established by document reading alone.

## Prioritized objections and proposed requirements

### 1. Major — a healthy helper cannot establish a live writer

**Dimension:** Observability & Operational SRE Debuggability.

**Affected scope:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “Browser and images,” lines 79–80; “Writer-controlled Director blocking,” lines 179–191; “Display agreement,” lines 231–238. `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, lines 39–49, 55, 79–80. `C:/Users/User/Documents/projects/CouldHappen/carryover_audit.md`, lines 65–71.

**Operational risk:** The browser/helper can remain responsive after the host has stopped servicing a wait. Conversely, a saved reply can still be animating after the writer has moved on. A persisted writer-declared production/blocking signal could survive an interruption and leave Director input apparently unavailable. A generic “connected,” “writing,” or “ready” indicator could then imply more than its source can establish. The current documents recognize this distinction but leave clearing and recovery open.

**Proposed mitigation requirement for the concept brief:** Status must describe evidence available to the component displaying it. Helper reachability is different from writer activity; absence of a reply is not proof of writer failure. After interruption or reopening, stale production/blocking declarations must have an understandable recovery path, and uncertain writer activity should remain uncertain. Explain how to inspect or re-enter the existing host session when the writer cannot report through Director chat.

**Strongest counterargument:** The human opened the host and can simply look at its terminal. That is a good default diagnostic route, and elaborate writer-presence detection may be less reliable than the underlying host. The remaining need is honest browser wording and recovery from stale restrictions, not a proof of continuous liveness.

**Genuinely smaller alternative:** Show only file-save/helper errors and the last writer-declared status with an explicit “last reported” meaning; direct uncertain cases to the host. Do not add heartbeat calls, timers that infer failure, remote telemetry, or a supervisor merely to animate “alive.” Exact status storage, expiry/reset rules, and wording belong to later design.

### 2. Major — the shared logs need enough evidence to locate an unanswered or repeated action

**Dimension:** Observability & Operational SRE Debuggability.

**Affected scope:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “Shared public conversation logs,” lines 160–173; “New proposals,” line 99. `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md`, lines 57–61. `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, lines 53–55.

**Operational risk:** After a timeout, interrupted save, or stale whole-file replacement, the human needs to distinguish “submission never persisted,” “persisted but not yet picked up,” and “a response exists but is not displayed.” Retrying an ambiguous submission can establish the same player action twice. Separate story and Director logs also make it hard to tell which correction the writer had actually read before a continuation. Host terminal output is useful but may not identify the particular durable entry involved.

**Proposed mitigation requirement for the concept brief:** Retain enough durable identity/order information at the browser/writer boundary to find a submitted human entry and its resulting handling or response without relying on the old host transcript. A helper failure must not be reported as successful persistence. Do not claim stronger delivery or exactly-once authoring guarantees than the chosen agreement supports. The demonstration should leave a readable explanation of an unanswered entry without exposing private plans.

**Strongest counterargument:** For a short local scene, role-marked entries and their order may be enough. Requiring a delivery ledger, acknowledgments at every stage, or per-message file creation would add protocol and maintenance cost before repeated-delivery failure is observed.

**Genuinely smaller alternative:** Reuse distinguishable entries in the accepted shared log and have the wait result name the entry it returned; use a visible save failure and manual inspection/re-entry through the host for ambiguity. Stable entry references are one possible later design, not an accepted schema. No separate event store, distributed trace, automatic retry controller, or second canonical manuscript is proposed.

### 3. Major — Undo's explanation and pending direction must survive the restore itself

**Dimension:** Observability & Operational SRE Debuggability.

**Affected scope:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “Git checkpoints and Undo,” lines 197–218; “Reopening,” lines 225–229. `C:/Users/User/Documents/projects/CouldHappen/carryover_audit.md`, lines 77–79.

**Operational risk:** The Director request can be newer than the selected checkpoint. Restoring files could remove that request, the writer's explanation, or the fact that the system is now waiting for direction. A helper or delegated writer still saving can then overwrite the restored state. A subsequent fresh session may see neither why content vanished nor which human correction remains applicable. A bare Git success is therefore insufficient evidence that the accepted Undo experience succeeded.

**Proposed mitigation requirement for the concept brief:** Recovery should leave a human-readable account of what checkpoint/scope was restored, material limitations or exclusions, retained Director guidance, and that further story production awaits direction. This account must remain discoverable after the actual restoration and a fresh reopen. The writer must establish a quiet boundary for relevant writers before claiming recovery complete, or explicitly report that it could not. This is an outcome proposal, not a demand for precise interaction rollback or total process cancellation.

**Strongest counterargument:** A writer can perform these steps through ordinary Director discussion and Git inspection; the notes already call out corrections, live context, untracked assets, and late writes. A mandatory machine recovery journal would duplicate the intended conversations and overformalize an occasional local operation.

**Genuinely smaller alternative:** Preserve the relevant Director conversation and write the restore report there after restoration, using available Git references and ordinary file inspection. Leave the detailed preservation/restore method to formal design. Do not add a branching application, transaction manager, per-interaction commits, or a promise that Git clears the live agent's context.

### 4. Major — a smooth short scene cannot establish interruption or fresh-context recovery

**Dimension:** Observability & Operational SRE Debuggability.

**Affected scope:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “First demonstration,” lines 104–106; “Reopening,” lines 225–229; “Assumptions,” lines 120–125. `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, lines 69–83.

**Operational risk:** Several successful exchanges and an Undo within one live context could conceal missing durable preferences, inaccessible working notes, or reliance on old transcript knowledge. It also does not expose the inactive-wait case in finding 1. If that pleasant run becomes the basis of a support claim, a normal restart can fail with no clear diagnosis. A checkpoint hook cannot certify literary continuity or semantic record completeness.

**Proposed mitigation requirement for the concept brief:** Preserve the accepted short-scene scope, but require a focused interruption/reopen observation before claiming the required fresh-context capability or normal interruption handling works. It may be a separate early check, as the notes allow. Judge the resulting continuation against the saved, human-visible fiction and retained Director guidance, rather than accepting the writer's assertion that it reread enough. Record the actual host surface/version and relevant model choice alongside the observation.

**Strongest counterargument:** The first demonstration is a scope sketch, not an approved test matrix, and formal evaluation details are intentionally deferred. This proposal should not turn brainstorming into an exhaustive host/model reliability certification or require extending the first run now.

**Genuinely smaller alternative:** One deliberate fresh compatible session on the same short-scene directory, with one known Director preference/correction and an established disclosure to check. A separate interrupted-wait observation can remain small. No fixed world schema, private-reasoning capture, full transcript replay, or universal model guarantee follows.

### 5. Nit — observe waiting overhead before instrumenting cost

**Dimension:** Observability & Operational SRE Debuggability.

**Affected scope:** `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, lines 90–91, 121–122; `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md`, line 26; `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, line 55.

**Operational risk:** “Polling is local” can be misread as “waiting has no host/model overhead.” Bounded waits, monitor renewal, and result servicing can still consume calls or attention. Conversely, requiring workspace-owned token metering could create unnecessary provider integration and misleadingly precise accounting.

**Proposed mitigation requirement for the concept brief:** Keep the compatibility observation explicit about whether no-input waiting returns to the model and what usage/responsiveness the host makes observable. Avoid a zero-cost or indefinite-session claim without evidence. Report unavailable cost information honestly.

**Strongest counterargument / smaller alternative:** Existing host usage display and a before/after note during one bounded idle observation are likely enough initially. Defer dashboards, cost databases, numerical thresholds, and new instrumentation unless actual experience identifies a decision they would change.

## Unresolved assumptions

- The actual interactive Claude Code and Codex surfaces can repeatedly service their chosen waiting mechanism; installed CLI flags and documented primitives do not establish that.
- A supported existing-host OpenRouter route can perform the required file/tool and wait behavior with a human-selected useful model. Provider selection support is not model reliability evidence.
- The shared log convention can remain understandable while avoiding accidental overwrite and self-triggering, even when the writer changes editing methods.
- A writer can leave discoverable knowledge and apply preferences after context loss while remaining free to reorganize its methods.
- A quiet restore boundary and retained Director instructions can be achieved with ordinary host tools and guidance; this need not imply a new controller.
- The browser can recover from stale blocking without pretending it can stop, resume, or inspect a host it does not control. Stop remains deferred.

## Concept decisions versus later design details

**Proposed concept commitments:** truthful component-level status; inspectable durable submission/response correspondence; recoverable Director guidance and a surviving Undo explanation; explicit post-restore waiting; fresh-context observation before capability claims; and observation of waiting overhead using existing diagnostics. These support the accepted experience without changing who controls the agent or when the writer commits.

**Suitable for later formal design:** filenames and entry format; whether references or acknowledgments are needed; conflict-safe write mechanics; exact production/blocking signal and stale reset behavior; hook event and concrete checkpoint condition; helper return/error shape; log locations; restoration command/scope and preservation sequence; and details of a small compatibility observation. None is selected here.

The concept should resist a common escalation: addressing every ambiguous pause by adding a session supervisor. The smaller first answer is durable, inspectable files, honest status, useful Director reports, and a documented route back to the existing host.
