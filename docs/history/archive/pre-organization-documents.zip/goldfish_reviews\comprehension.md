# UX & Ergonomics brainstorm findings

Persona: **UX & Ergonomics-Brainstormer**, using the installed Comprehension Goldfish persona in **BRAINSTORM** mode. This is concept stress-testing through UX, developer ergonomics, and cognitive overhead, not a formal comprehension audit. Recommendations below remain proposals for the Concepts Brief; they are not accepted requirements or implementation authorization.

## Read receipts and boundaries

Read in full:

- `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/comprehension.md` — entire persona, including universal mandates, BRAINSTORM instructions, REVIEW-only instructions, and output formats. BRAINSTORM requires UX/developer ergonomics feedback; it names no additional standards to read. **Standards receipt: none required.**
- `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` — all 294 lines. Initial raw output was truncated, so numbered reads covered lines 1–130 and 131–294; a final read of 267–284 recovered the output's abbreviated portion. Working hypothesis through final readiness statement read.
- `C:/Users/User/Documents/projects/CouldHappen/prior_imagery_findings.md` — all 41 lines, raw and numbered reads; current direction, historical findings, visual evidence, carry-over, and clarification read.
- `C:/Users/User/Documents/projects/CouldHappen/carryover_audit.md` — all 89 lines, raw and numbered reads; user resolution, all six historical findings, intentional changes, and assessment read.

No other reviewer findings, prior-project files, hidden conversations, credentials, live providers, installations, implementation, image generation, or Impeccable execution were used. Only this findings artifact was written under the caller's explicit exception to the persona's read-only mandate.

## Concept assessment

The concept gives a fiction writer an existing agent host rather than building a new agent application. A local browser exchanges durable public story and Director entries; the writer maintains its own discoverable knowledge, code, and checkpoints. Its strongest ergonomic advantage is that a trusted single user can discuss changes naturally in Director chat and let the writer adapt its methods. The main ergonomic risk is that the browser can appear like a continuously available application while the actual writer remains a host session with unverified waiting, interruption, and resumption behavior.

No finding below justifies reinstating the prior controller, schema, Accept/Revise workflow, or exact interaction rollback. The notes already recognize most uncertainties honestly. The useful next step is to choose a few observable user-facing promises that let the short scene test those uncertainties.

## Prioritized objections

### 1. Major — A silent browser stall leaves the player without a next action

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, Working hypothesis lines 15–17; Browser and images line 79; Assumptions lines 121–124; Current discussion line 268. Supporting `carryover_audit.md`, User resolution line 15 and Useful visibility lines 65–71.

**Usability friction:** A saved player message, a host awaiting terminal polling, a writer doing private work, and a dead helper can all look like “nothing happened.” Director chat cannot explain the failure if the writer is unavailable. An impressive uninterrupted demo could therefore hide a workflow that needs the human to diagnose tools or guess whether resending duplicates an action.

**Proposed ergonomic requirement:** The brief should require an understandable next step for an unanswered saved input and for a known local connection failure. Distinguish what is known: “saved locally; awaiting writer” is an honest observation; “writer connected” is a stronger claim that requires evidence. Include a documented return-to-host/reopen route and retain the player's unsatisfied input rather than asking them to reconstruct it. Do not label a response successful merely because submission was saved.

**Strongest counterargument:** Trusted local use already exposes the host terminal, and a custom availability monitor would be disproportionate. Agreed: this need not establish liveness, timers, retries, or a dashboard.

**Genuinely smaller alternative:** A persistent “Open the agent session if this remains unanswered” instruction, clear local-save acknowledgment, and actionable error text for failures the helper actually observes. A user-invoked resume instruction can be sufficient; automatic recovery is not necessary.

**Unresolved assumption:** Can a supported host resume processing an outstanding entry without duplicate story output? The notes contain no executed evidence. Decide the acceptable manual interruption experience at concept level; helper mechanics and host-specific diagnostics belong in formal design.

### 2. Major — Two public logs need one understandable rule for when instructions take effect

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, Shared public logs lines 160–173; Writer-controlled blocking lines 179–191; Git recovery lines 199–201. Supporting `carryover_audit.md`, Director discussion lines 25–31.

**Usability friction:** A Director message such as “make the next passage shorter” or “undo that” may arrive while the writer composes a response or while an already-saved response animates. The player cannot infer whether the instruction applies to the current prose, the next response, or only after an acknowledgment. The writer's discretion to block Director entry is accepted, but leaving it open must not imply immediate interruption. Story submissions during production are also explicitly unsettled.

**Proposed ergonomic requirement:** Preserve writer-controlled Director blocking while defining the visible meaning of an accepted submission. Submission is not acknowledgment or application. The writer should make the effective point clear when it answers, especially for instructions received during production and for Undo. After Undo, any already-waiting story action must not silently trigger replacement prose before Director guidance. Pick a simple first-version behavior for additional story submissions rather than inheriting a generic chat queue accidentally.

**Strongest counterargument:** Natural conversation and agent judgment can resolve most timing ambiguities without a scheduler. Agreed: no priority queue or cross-log transaction system is implied.

**Genuinely smaller alternative:** Starter guidance says to inspect outstanding Director messages at a useful boundary before the next story continuation and acknowledge what they affect. A short browser sentence explains that an in-flight response may finish before a new Director instruction is read. The first template can allow only one outstanding story submission while leaving Director availability at the writer's discretion, if the user accepts that proposal.

**Unresolved assumption:** Whether the writer can notice new messages during its current work is host/tool dependent. Choose the user expectation now; defer IDs, ordering fields, and exact polling boundaries to formal design.

### 3. Major — Honest checkpoint limits must become understandable recovery consequences

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, Git checkpoints and Undo lines 197–219, especially 205, 215, and 219; Workspace and persistence line 72. Supporting `carryover_audit.md`, intentional changes line 78.

**Usability friction:** “Undo the last response” can recover a checkpoint spanning several exchanges and containing method improvements, cast changes, or preferences. Listing commit hashes alone will not tell a reader what they will lose. Restoring the Director log itself can erase the reason for rejection or leave the conversation apparently unanswered. These are surprising consequences even though imprecise rollback is explicitly accepted.

**Proposed ergonomic requirement:** Explain recovery in story/user terms: which visible passages return, which later exchanges or other work fall outside the checkpoint, and which applicable Director corrections remain in force. Distinguish historical restoration from newly reconstructed text. Report the result in Director chat and wait as already required. The aim is legibility, not a confirmation gate for every reversible restore.

**Strongest counterargument:** The user accepts coarse history and has explicitly delegated checkpoint timing; an elaborate timeline would undermine the lightweight premise. Agreed: one concise Director explanation is enough when the scope is simple.

**Genuinely smaller alternative:** Have the writer inspect history and summarize a recoverable story point in natural language before carrying out the requested restoration. Keep the relevant rejection/correction available by a small retained recovery note or other writer-chosen method. No new branch UI or per-interaction commit rule is needed.

**Unresolved assumption:** The writer can identify the narrative meaning of available history and preserve instructions without preserving rejected plans as authority. Test this with a deliberately imperfect checkpoint, rather than only a conveniently exact one. Choose the explanation promise at concept level; restoration commands and retained-note layout are later design details.

### 4. Major — Writer freedom needs a stable way to discover the current working method

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, Workspace and persistence lines 66–70; assumptions line 128; fresh-context continuation lines 225–238; anchored hypothesis lines 288–290. Supporting `carryover_audit.md`, preferences lines 57–63 and continuation line 77.

**Usability friction:** Allowing the writer to reorganize notes, skills, helpers, and the browser is valuable. A fresh host must still know where authoritative records and current browser conventions moved. Otherwise portability becomes a debugging task for the human, or the new session quietly operates on stale instructions. A directory full of durable files is not by itself discoverable state.

**Proposed ergonomic requirement:** Preserve a small, obvious bootstrap route that tells a fresh supported session where to begin and how to find current records and public interface conventions. Writer-led reorganization must leave that route valid. The human should not need to remember filenames from an earlier conversation. Assess fresh-context continuation from a genuinely fresh session, including at least one applicable Director preference, rather than treating saved notes as proof.

**Strongest counterargument:** The notes already require discoverability, and a fixed schema would constrain adaptive authorship. Agreed: this finding sharpens the user-visible outcome and does not require fixed private records or automatic preference injection.

**Genuinely smaller alternative:** One short start-here instruction or existing host entry file can point to the writer's current working index. Updating a pointer is smaller than building a registry, migration engine, or standardized world database.

**Unresolved assumption:** Different selected models will reliably maintain and consult the route. Host compatibility does not establish semantic continuity for every model. Require a supported route and demonstrate specific configurations; avoid a universal model-quality claim. Decide the discovery invariant at concept level; names and formats are later design work.

### 5. Major — A shared editable log can impose accidental constraints on ordinary writing

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, prose editing lines 142–156; shared log lines 160–170; display agreement lines 233–238.

**Usability friction:** A single readable conversation file reduces files and preserves player prose, but it combines human submission, writer editing, response detection, and animated presentation. If the implementation quietly relies on append-only writes or exact text matching, ordinary replacement saves or an authorized revision can duplicate inputs, erase intervening messages, or replay animation. The user would then have to learn hidden file-editing restrictions despite the promised tool freedom.

**Proposed ergonomic requirement:** Maintain the accepted shared log and writer choice of tools while making entries reliably distinguishable and preventing silent loss from overlapping saves. Browser behavior should survive normal save/reload patterns without replaying old prose as new. A rejected or temporarily incomplete save should preserve readable existing content and surface an actionable problem rather than appearing to delete the story.

**Strongest counterargument:** A trusted single user and sequential writer workflow greatly reduce collision frequency. Agreed: enterprise synchronization, distributed transactions, and arbitrary external editing guarantees would be excessive.

**Genuinely smaller alternative:** Start with visibly distinguishable entries, a short collision-avoidance convention, and a helper that preserves the latest readable content when it cannot yet read a valid update. A brief no-overlapping-story-submission convention could narrow the problem if accepted, but it cannot silently become a mandatory Director block or append-only writer tool.

**Unresolved assumption:** Which small convention actually works with free editing methods and normal host tools? This is a central implementation hypothesis to prototype later, not a reason to select a heavy publication protocol now. Choose preservation and discoverability outcomes at concept level; exact format, entry identities, and save technique belong in formal design.

### 6. Nit — Reveal animation and cast presentation can delay or obstruct reading

**Dimension:** UX & Developer Ergonomics.

**Scope:** `brainstorming_notes.md`, display lines 148–156 and production/reveal distinction line 191. `prior_imagery_findings.md`, placement line 17, historical reading considerations line 27, and current direction lines 33–41.

**Usability friction:** A fully saved paragraph can remain unavailable to a fast reader while animated reveal continues. File replacement or Undo can also disorient a reader if the viewport jumps. A cast panel consumes width and mixed-source portraits can make an otherwise readable template unstable. These are especially visible in a short demo, but do not justify revisiting the accepted portraits/cast arrangement.

**Proposed ergonomic requirement:** In the later comp-led pass, include the actual reading states: new prose arriving, older prose being read, a revision/Undo replacing text, Director discussion, and a narrow viewport with cast access. Propose an immediate-reveal convenience and respect reduced-motion settings. Keep animation distinct from writer activity and preserve the reader's place where feasible.

**Strongest counterargument:** Animation is an accepted preference, and historical responsive ideas are not new-project approvals. Agreed: these remain specific proposals to assess in the scheduled design pass, not retroactive visual requirements.

**Genuinely smaller alternative:** A simple reveal-all action or reduced-motion bypass, a collapsible cast on narrow views, and a visible new-prose cue while the reader stays above it. No timeline, elaborate diff view, or media pipeline is necessary.

**Unresolved assumption:** Whether a small changed-passage indicator is cheap enough remains open. Decide basic reading usability before visual polish; exact transitions, typography, and layout follow in Impeccable/formal design.

## Smallest useful concept validation

Keep the accepted short scene. Propose adding only a few deliberate observations to that scene or a separate early check: submit one Director instruction while prose is in progress; encounter one recoverable host/helper interruption; undo from history that has a real scope limitation; and reopen from fresh files with a remembered Director preference. These checks target the promised experience and do not require a mystery arc, broader reliability benchmark, or new telemetry database.

Claude Code and Codex remain required support targets. At least one supported existing-host OpenRouter route remains required. First-host choice, exact model-quality claims, acceptable manual interruption effort, and whether restart is inside the scene or a companion check remain unresolved. A compatibility summary should distinguish a working browser/file loop from hooks actually active in that host and from story-quality evidence; no implementation evidence was established by this review.

## Concept choices versus later formal design

Resolve in the Concepts Brief: the acceptable interruption/resume burden on the human; the meaning of a submitted versus acknowledged Director instruction; first-version handling of additional story input during production; the recovery explanation promise; and the durable discovery invariant. Preserve accepted writer discretion, checkpoint limitations, natural Director discussion, and the short-scene scope.

Leave for formal design: public file syntax and identities, exact helper/API/CLI commands, host hook events and activation steps, quiet restore boundaries, retained-instruction technique, index filenames, cast discovery format, frontend stack, and detailed animation/layout. Those details deserve evidence and implementation work later; their absence is not itself a brainstorm blocker.

**Conclusion:** No concept-level Blocker found in this lens. Five Major ergonomic risks need bounded user-facing promises and later evidence; one reading/presentation Nit belongs in the scheduled visual exploration. The concept can remain substantially smaller than a dedicated fiction controller if it makes interruption, timing, recovery, and fresh-start behavior understandable rather than hiding them behind apparent browser availability.
