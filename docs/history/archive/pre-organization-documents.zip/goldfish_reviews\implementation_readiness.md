# Migration & Rollback Goldfish — BRAINSTORM findings

Persona: **Implementation Readiness Goldfish**, acting as **Migration & Rollback-Brainstormer** under its BRAINSTORM branch. This evaluates persistent-file compatibility, host changes, rollout, and recovery hypotheses; it does not audit implementation actionability or demand a complete formal design.

## Reading receipts

Read in full, including frontmatter and both mode branches:

- `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/implementation_readiness.md` — complete installed persona, from opening frontmatter through the BRAINSTORM output requirements.
- `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` — all 294 lines. Full-read receipt: lines 1–107 and 108–294 were individually returned without omission after an initial combined result was truncated. Includes the anchored hypothesis and current authorization boundary at lines 286–294.
- `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md` — all 85 lines, individually returned in full. Includes the evidence boundary and remaining questions at lines 77–85.
- `C:/Users/User/Documents/projects/CouldHappen/carryover_audit.md` — all 89 lines, returned in full. Includes the accepted user resolution at lines 8–17, deliberate changes at lines 73–83, and historical assessment at lines 85–89. The assessment's earlier statement that no Goldfish have launched is historical relative to the current assignment, not evidence against this authorized review.

Standards receipt: **none required for BRAINSTORM**. The persona requires a Target Standard audit only in REVIEW mode; no template or implementation-readiness standard was imported. No previous-project source, other reviewer output, hidden conversation, credentials, live provider, installation, implementation, or image workflow was consulted. Only this findings file was written.

## Overall judgment

The concept has no existing production clients or serialized world schema to migrate. A production migration framework would be disproportionate. Its relevant migration is the movement of a living, editable story directory between checkpoints, helper/interface revisions, fresh sessions, and supported hosts. The hypothesis is plausible, with three material risks to resolve through concept choices and focused observations. These are unresolved trade-offs already partly identified in the notes, not evidence that the small approach has failed.

All recommendations below are proposals. They do not approve implementation, select a host, mandate commit-per-response history, or reinstate the old controller.

## 1. Major — Story Undo can restore incompatible running control state

**Dimension:** Migration & Backward Compatibility.

**Affected scope:** `brainstorming_notes.md`, “Shared public conversation logs,” lines 166–173; “Writer-controlled Director blocking,” lines 179–183; “Git checkpoints and Undo,” lines 197–219. Also `carryover_audit.md`, lines 78–82.

**Compatibility hazard:** Git can restore the intended prose and notes while a browser or waiting helper still holds a later view of the log, a consumed-input position, or a writing/blocking signal. If a restored human entry appears unhandled again, the ordinary wait loop could produce another story response before the required Director direction. A browser save based on its old copy could also write rejected material back into the restored log. If the writer changed helper/UI files in the same interval, restored code may differ from code still running. A quiet writer alone does not reconcile these consumers.

The notes already identify concurrent writes, uncommitted material, active subagents, retained corrections, and live model context. The additional stress case is a correctly restored filesystem paired with stale browser/helper state. This would violate the accepted post-Undo wait even with honest checkpoint granularity.

**Proposed migration requirement for the concept brief:** Treat restoration as incomplete until relevant writers/readers have re-established the restored view and the workflow is waiting for Director direction. Preserve the rejection reason and applicable preferences before restoring their older files. Do not claim success merely because a Git command succeeded. Decide whether the initial demonstration can use a deliberate quiet boundary and helper/browser reload rather than automatic coordination.

**Strongest counterargument:** This is trusted single-user local play, and Undo is an explicit Director conversation. The writer can explain the recovery and manually reopen the interface. Such a procedure may be entirely sufficient; no browser Stop or distributed transaction layer follows from the risk.

**Genuinely smaller alternative:** A documented assisted Undo: pause relevant file work, preserve the current Director instruction, restore the agreed scope, relaunch/reload the small helper/interface if needed, and return to Director waiting. If the live writer cannot reliably abandon rejected authority, a fresh compatible session is a fallback to evaluate, not a mandatory reset after every Undo.

**Unresolved assumption:** Can the existing host and minimal helper reach that quiet, re-established state while retaining the Director instruction and avoiding automatic replay? The demonstration can observe this directly.

## 2. Major — Editable public conventions and private-method freedom need different compatibility expectations

**Dimension:** Migration & Backward Compatibility.

**Affected scope:** `brainstorming_notes.md`, lines 65–69, 77, 99, 128, 142–156, 160–173, and 223–238; `host_compatibility_notes.md`, lines 53 and 69–75.

**Compatibility hazard:** The writer is allowed to reorganize records, edit skills/scripts, and customize the interface. Private-method changes are mostly the writer's concern, but changes to story/Director entry interpretation affect the browser and wait helper too. A format change made while an old browser tab/helper runs can misclassify an edit as a new player action, lose a pending entry, or expose the wrong material. A fresh host may find an obsolete starting instruction after the writer moved its working records. No fixed world schema is needed for these failures.

The notes correctly call for a small discoverable agreement and leave its format open. The consequential concept choice is whether changes to that public agreement are ordinary live customization or deliberate maintenance between play stretches. Those have substantially different coordination costs.

**Proposed migration requirement for the concept brief:** Preserve a discoverable way to find the current public agreement and private-note entry points. Changes crossing the browser/writer boundary must account for the current logs and active readers rather than silently replacing their interpretation. This is an interoperability outcome, not a demand for a specific schema, version registry, or authoring tool.

**Strongest counterargument:** A single writer controls the workspace and can update the relevant files together. The first scene may never change the public format. Building a general migrator now would solve a hypothetical problem and undermine the minimum-package goal.

**Genuinely smaller alternative:** Keep the initial public agreement stable during ordinary play; allow public-convention changes at an explicit maintenance/reopen boundary with a backup and reload. Continue allowing free choice of writing tools, UI presentation, and private record organization. A short readable entry-point note can support reopening without an internal schema or automatic migration manager.

**Unresolved assumption:** Will the writer preserve/revise discoverability when adapting its methods, and can a genuinely fresh compatible session find the current knowledge without relying on the previous host conversation? The required restart outcome should receive an early observation, either alongside the short scene or separately; it need not expand that scene into a mystery arc.

## 3. Major — Checkpoint enforcement does not automatically survive a host change or hook edit

**Dimension:** Migration & Backward Compatibility.

**Affected scope:** `brainstorming_notes.md`, lines 70–71, 197, 211, and 282–290; `host_compatibility_notes.md`, lines 9–11, 39–49, 57–63, and 77–83; `carryover_audit.md`, line 82.

**Compatibility hazard:** A workspace can contain a valid hook definition while the new host surface has not activated it. The supplied host investigation specifically distinguishes saved Codex hook source from trust/activation and distinguishes host-turn completion from each prose exchange. Porting the directory from one required host to the other, restoring an older hook, or allowing the writer to edit a hook can therefore change checkpoint enforcement while the workflow still appears operational. A long tool-wait loop may never reach the chosen Stop boundary during several exchanges.

This does not mean every exchange needs a commit. It means “hooks ensure changed work is checkpointed” is conditional on activation and the actual boundary; restoring the hook file is not restoration of that condition.

**Proposed migration requirement for the concept brief:** Describe checkpoint enforcement as a host/surface capability with a normal activation path. On reopening or after relevant hook changes, do not silently claim enforcement that is unverified or inactive. Select the useful checkpoint condition and event through focused host investigation, retaining writer-chosen meaningful commit timing. Distinguish an explicit assisted fallback from supported enforcement.

**Strongest counterargument:** These limits are already documented, and the host's normal trust behavior may make them obvious to the human. A common local wait helper may provide a useful check without a separate hook system for every host. No new controller or host-wide permissions policy is warranted.

**Genuinely smaller alternative:** Separate brief host adapters/instructions that use each host's existing mechanisms, with an explicit reopen/activation check. Investigate a small check at an existing wait boundary if it provides a better fit; do not make a per-response commit mandatory merely to simplify enforcement. A host/model pair with missing enforcement remains an honestly limited candidate rather than an invitation to build a provider controller.

**Unresolved assumption:** Which concrete supported boundary is both reachable during ordinary play and useful for checkpoint assurance in Claude Code, Codex, and the selected existing OpenRouter route? Documentation and executable version observations do not yet settle this. Model selection also does not demonstrate the model's ability to maintain records or honor restoration instructions.

## 4. Nit — Future template updates should not overwrite a customized story directory

**Dimension:** Migration & Backward Compatibility.

**Affected scope:** `brainstorming_notes.md`, lines 65–69, 77, and 288–290.

**Compatibility hazard:** A reusable template can eventually be recopied into an existing workspace. Blind replacement could erase writer-created methods or replace an interface/helper without updating its existing records. There is no current installed base, and no updater is proposed, so this is not a blocker or a reason to add migration infrastructure.

**Proposed migration requirement for the concept brief:** If updates to existing workspaces become part of the product claim, make the preservation of story records and local customization explicit. Until then, avoid implying that template replacement is an automatic safe update operation.

**Strongest counterargument and smaller alternative:** Ship a copy-once template initially; make subsequent adoption of changes an explicit read/review/merge using Git when needed. Defer automatic update support and its compatibility machinery until there is a real update scenario.

## Concept choices versus later design

Useful concept choices now are whether assisted quiet-boundary Undo/reload is acceptable; whether changes to the public agreement occur between play stretches; how inactive checkpoint enforcement is communicated; and whether fresh-context continuation is observed within the scene or as a separate early check. These decide the scope of the promise without fixing private methods.

Exact log syntax, cursor storage, conflict detection, restoration commands, checkpoint condition, hook implementation, status clearing, root-note filename, update tooling, and browser reload mechanics belong in later design after these choices and focused evidence. No exact latest-interaction restoration, universal OpenRouter-model reliability, exhaustive import-compatibility matrix, or general migration service is justified by this review.
