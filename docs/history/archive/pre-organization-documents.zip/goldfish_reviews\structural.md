# Maintenance & Coupling Goldfish: BRAINSTORM findings

Persona: installed **Structural Goldfish**, applied in its **BRAINSTORM** role of long-term tech debt, coupling, and maintainability. This is an independent concept review, not a heading/template audit. Review date: 2026-11-03. Recommendations below are proposals for discussion, not accepted requirements or implementation authorization.

## Full-read and standards receipts

Read the installed persona in full: `C:/Users/User/.codex/plugins/cache/egm/egm/0.1.0/agents/structural.md`, lines 1–65, 4,019 bytes, SHA256 `0910C45B02618A7AA017F3ADCAF7C6866C35668BD2AAEF1DB30A0C3D9B6B522E`.

Read every assigned project document in full. The first batched output truncated the primary target; it was reread in two complete, untruncated ranges (1–110 and 111–294) before this report. Supporting-document outputs were complete.

| Absolute path | Full range | Bytes | SHA256 |
| --- | --- | --- | --- |
| `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md` | 1–294 | 44,502 | `4E6D24F394032B9AA2846423ABB9885F20334654C76883392589DFEDA664ACF3` |
| `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md` | 1–83 | 15,116 | `F7D320E47DBA1613A90199ED42242670CBAFF15475977F0C2960E923570CCD48` |
| `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md` | 1–85 | 11,085 | `10D75CEEEEADDB840945352E16C773810B353F29CA302586BBACD1E88EE11EB1` |
| `C:/Users/User/Documents/projects/CouldHappen/prior_imagery_findings.md` | 1–41 | 5,309 | `AA1DB718F22B8F6145CDEC3976BF59A1622B2814DEBA596D21FFB2CBACAC9FE3` |

Standards receipt: **none required by the installed persona for BRAINSTORM**. Its formal Target Standard/template audit applies to REVIEW mode. No structural template or previous-project architecture was applied. No previous-project files, hidden chats, credentials, other reviewers' findings, or live providers were read. No implementation, installation, image generation, or Impeccable execution was performed. Only this findings file was written under the caller's explicit exception to the persona's read-only rule.

## Assessment

No concept-level Blocker found. The existing-host/local-helper boundary is credible enough to keep exploring, and the supplied evidence already supports basic browser handoff precedent. The largest maintenance risk is the intersection of independently editable shared logs, restorable writer materials, and host-specific waiting/checkpoint behavior. Each is modest alone; allowing their conventions to drift independently could create an implicit controller spread across skills, hooks, browser code, and notes.

The notes already identify many of these uncertainties honestly. The findings below identify where a small concept-level invariant would prevent those acknowledged questions becoming a permanent integration burden. They do not assert that the proposed capabilities have been demonstrated.

## Prioritized objections and proposals

### 1. Shared-log freedom needs a narrow mutation agreement

**Severity: Major. Dimension: Long-Term Tech Debt & Maintainability.**

Affected scope: `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “Prose display” lines 142–156; “Shared public conversation logs” lines 160–173; `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md`, lines 57–63.

Tech debt description: the browser and writer both modify a file, while the writer can replace it through arbitrary supported tools. A browser save based on an earlier copy can erase prose, or a writer replacement can erase a new human entry. A helper that infers new input from textual differences also risks treating a corrected passage as a new action. Adding separate fixes to the browser, wait script, display animation, and skills would tightly couple them to incidental text formatting. Separate Director traffic increases the coordination cases even in trusted single-user use.

Strongest counterargument: the document explicitly recognizes conflicting saves, unhandled entries, and authorized edits. One user and one writer can avoid most overlap with ordinary turn-taking. This does not justify a database, transaction system, or mandatory authoring tool.

Proposed maintainability requirement for the concept brief: agree that input acceptance and writer saving cannot silently overwrite each other, and that a human entry has a durable identity distinct from an edit or a prose save. Preserve writer choice of editing method. The brief should acknowledge what concurrency the first version actually supports rather than claim the format alone solves it.

Genuinely smaller alternative: serialize acceptance of story submissions during a story-log write, with an unsent browser draft retained locally; leave Director input available according to the writer's accepted discretion. A narrow safe-save convention or conflict refusal may be enough. This is a proposal requiring alignment because ordinary player submission behavior is currently open. An append-only writer tool, per-message file system, or new event service is not automatically smaller.

Concept choice now: permitted overlap and the no-silent-loss outcome. Later formal-design details: entry markers/identifiers, safe-save checks, exact file format, and animation reconciliation.

### 2. Undo must reconcile delivery state as well as story files

**Severity: Major. Dimension: Long-Term Tech Debt & Maintainability.**

Affected scope: `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, “Required outcome” lines 197–201, “Proposed smallest approach” lines 209–219, and input recognition lines 168–173; `C:/Users/User/Documents/projects/CouldHappen/browser_handoff_research.md`, lines 61 and 74.

Tech debt description: a recovered log may contain earlier human messages that a fresh wait treats as unhandled; a surviving helper may retain a cursor referring to withdrawn entries; a pending story input can still be queued while Undo is discussed. These delivery states can bypass the accepted post-restore wait for Director direction even when prose and notes are restored correctly. Restoring files can also remove the Director explanation or retain an input acknowledgment whose story response no longer exists. Fixing these independently would create a brittle recovery state machine.

Strongest counterargument: exact interaction rollback is expressly disclaimed; Undo is an agent-handled Director operation with a quiet writing boundary already identified. The writer can explain coarse recovery and manually reconcile a small local session. There is no need to resurrect the former application's transactional machinery.

Proposed maintainability requirement: after restoration, outstanding story delivery cannot cause fiction to continue before new Director guidance; retained Director corrections must remain discoverable. Treat helper/browser cursors and queued inputs as reconciliation concerns, not as evidence of fictional authority. Keep this outcome independent of whether Git restores one exchange or several.

Genuinely smaller alternative: at a quiet boundary, temporarily stop input servicing, restore the chosen story scope, reopen the helper/page from the retained conversation position, and explicitly wait on Director input. If manual queue reconciliation is needed initially, say so. A durable restore record containing target and retained instruction may be useful, but an automatic branch tree or exact rollback journal is unnecessary.

Concept choice now: stale delivery cannot resume story writing after Undo. Later formal-design details: cursor location, pending-input disposition, restoration commands, and status reset. No commit-per-interaction rule is proposed.

### 3. Writer-editable infrastructure can roll back its own recovery path

**Severity: Major. Dimension: Long-Term Tech Debt & Maintainability.**

Affected scope: `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, workspace autonomy lines 65–71, restoration concerns lines 215–219, editable browser line 77; `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, Codex trust behavior lines 47–49 and activation evidence line 83; `C:/Users/User/Documents/projects/CouldHappen/prior_imagery_findings.md`, public discovery lines 35–41.

Tech debt description: the writer may change its skills, helper scripts, hooks, browser, and private organization. A later story restore may also restore an older helper convention or hook definition. The live browser and agent can then disagree with disk; a reverted Codex hook can require renewed trust before activation. A story correction could unexpectedly become an infrastructure repair. Keeping all files in Git does not itself separate these lifecycles.

Strongest counterargument: editable methods and presentation are an intentional strength. A trusted local writer can inspect changes, retain useful improvements, and restart helpers. A package manager, immutable core, or plugin framework would add disproportionate machinery.

Proposed maintainability requirement: identify the small public agreement shared by browser, waits, skills, and cast discovery, and make its current entry point discoverable. Story recovery must inspect infrastructure changes rather than assume an indiscriminate workspace restore is safe. Explicitly distinguish changing a hook file from activating/trusting it. Preserve the writer's right to evolve its methods.

Genuinely smaller alternative: a short human-readable workspace map and compatibility note, with an explicit helper restart after relevant changes; inspect the Git diff before selecting the restore scope. Private notes remain free-form. Do not require semantic versioning, a package registry, or a fixed world schema.

Concept choice now: public interoperability conventions and their activation path survive method changes and recovery. Later formal-design details: exact bootstrap file, whether a tiny convention version is useful, and the default Git restore scope.

### 4. Required-host portability can multiply hidden lifecycle adapters

**Severity: Major. Dimension: Long-Term Tech Debt & Maintainability.**

Affected scope: `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, support targets lines 13–17 and 40, hypothesis lines 288–290; `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, shortlist lines 23–33, Claude/Codex behavior lines 37–49, hook boundaries lines 57–63, and evidence still needed lines 79–85.

Tech debt description: portability is currently a family of similar primitives rather than one proven lifecycle. Waiting result delivery, host completion, checkpoint hooks, hook trust, session surfaces, and provider/model tool behavior can change independently. If the helper begins restarting sessions, selecting models, or compensating for every host difference, the no-controller boundary erodes without a single obvious architectural decision. The OpenRouter route may add a launcher dependency even if it adds no provider client.

Strongest counterargument: both required hosts have documented primitives and firsthand browser precedent. Most data and helper code can stay shared. OpenRouter may work through one required host, so a third host is not necessarily needed; universal model reliability is already disclaimed.

Proposed maintainability requirement: keep host-specific lifecycle instructions small and explicit, distinguish supported host/surface behavior from candidate integrations, and keep model/credentials/session ownership in the existing host. An unsupported capability should produce an honest setup/reopen instruction rather than silently accrete a provider or session controller.

Genuinely smaller alternative: one portable file/helper agreement with concise Claude Code and Codex guidance, validating each required host's actual waiting/checkpoint path; satisfy OpenRouter through one verified existing route. Leave the additional four candidates as comparisons until their maintenance cost is justified. A native monitor is optional where available, not an abstraction every host must emulate.

Concept choice now: support means demonstrated ordinary loop plus an explicit interruption/reopen path for a named host surface, with limitations recorded. Later formal-design details: initial versions, hook events, wait timeouts, diagnostics, and specific OpenRouter route. Existing required support targets are retained, not reduced.

### 5. Free-form durable records need a stable reentry obligation

**Severity: Major. Dimension: Long-Term Tech Debt & Maintainability.**

Affected scope: `C:/Users/User/Documents/projects/CouldHappen/brainstorming_notes.md`, persistence lines 66–70, rejection line 72, “Reopening and fresh-context continuation” lines 225–229; `C:/Users/User/Documents/projects/CouldHappen/host_compatibility_notes.md`, lines 69–75.

Tech debt description: records can be adequate for their current author yet undiscoverable to a fresh session after methods change. Over time, preferences may exist in Director discussion, summaries, and private records with unclear precedence. A polished short scene can conceal this drift because the current context supplies missing knowledge. Reading the entire growing transcript to compensate would violate the intended durable-world approach and create escalating context cost.

Strongest counterargument: the notes expressly require durable discoverable knowledge and recognize that hooks cannot certify semantic completeness. A fixed world database or mandatory dossier schema would constrain useful writer adaptation without proving continuity.

Proposed maintainability requirement: every method reorganization leaves a discoverable entry point explaining current authoritative records and where retained Director guidance lives. Fresh-context continuation is an observable behavior to evaluate, not something inferred from file existence or a successful commit. The writer may choose the actual organization.

Genuinely smaller alternative: one maintained workspace reading map linking the writer's own notes, current scene/prose position, applicable corrections/preferences, and relevant disclosure records. Evaluate a fresh compatible session on a short scene containing a private fact and a Director correction. This may be a separate early check, as the accepted demonstration already allows; it need not become a long mystery benchmark or a fixed semantic schema.

Concept choice now: discoverable reentry survives method changes, and semantic continuation gets an early check. Later formal-design details: filenames, record categories, sampling procedure, and which portions of old prose to reread.

## Unresolved assumptions and proportionality

- Ordinary player input overlap is still open. The safe shared-log arrangement cannot be selected solely from the single-user label because the writer, browser, and local helper still act concurrently.
- Required hosts' exact session surfaces, practical interruption behavior, and checkpoint boundary remain untested. Documentation is useful evidence, not a compatibility result.
- The minimum story restore scope and whether infrastructure improvements should survive that restore are unsettled. A blanket workspace reset is not assumed.
- Whether a fresh session can reliably distinguish restored authority from rejected developments remains an outcome question; neither Git nor a clever schema can guarantee literary quality.
- Public cast discovery is a real cross-boundary need, but supplied PNG reuse does not justify an asset pipeline. One small public names/portrait convention should suffice pending evidence.
- The browser/helper can become unavailable while the writer is unable to report through Director chat. A plain reconnect/reopen indication may suffice; a custom operational dashboard is unwarranted.

For trusted single-user local use, none of these findings calls for containers, access-control services, database transactions, universal model conformance, elaborate security layers, or a replacement host. The accepted short-scene scope remains a sensible first demonstration. A useful concept brief should settle the few behavioral boundaries above while leaving file formats, hooks, scripts, framework, and recovery commands to formal design after alignment.
